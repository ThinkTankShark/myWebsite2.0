$(".alert" ).fadeOut(6000);
$(".alert-success" ).fadeOut(6000);
$(".alert-danger" ).fadeOut(6000 );
